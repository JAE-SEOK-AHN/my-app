package com.barunsw.simple.sample;

import java.util.List;

public interface SampleService {
	
	public List<SampleVo> selectSampleList(SampleVo sampleVo);

	public SampleVo selectSampleOne(SampleVo sampleVo);
	
	public int insertSample(SampleVo sampleVo);
	
	public int updateSample(SampleVo sampleVo);
	
	public int deleteSample(SampleVo sampleVo);
	
}
