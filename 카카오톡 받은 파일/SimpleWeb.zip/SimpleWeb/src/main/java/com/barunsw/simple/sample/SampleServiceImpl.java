package com.barunsw.simple.sample;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SampleServiceImpl implements SampleService {
	
	@Autowired
	private SampleDao sampleDao;

	@Override
	public List<SampleVo> selectSampleList(SampleVo sampleVo) {
		return sampleDao.selectSampleList(sampleVo);
	}

	@Override
	public SampleVo selectSampleOne(SampleVo sampleVo) {
		return sampleDao.selectSampleOne(sampleVo);
	}

	@Override
	public int insertSample(SampleVo sampleVo) {
		return sampleDao.insertSample(sampleVo);
	}

	@Override
	public int updateSample(SampleVo sampleVo) {
		return sampleDao.updateSample(sampleVo);
	}

	@Override
	public int deleteSample(SampleVo sampleVo) {
		return sampleDao.deleteSample(sampleVo);
	}

}
